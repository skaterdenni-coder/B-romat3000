#include "WiFiS3.h"
#include "index.h" // Bindet deine HTML-Oberfläche ein

// Access Point Zugangsdaten
const char* ssid = "Baeromat3000";
const char* password = "gummibaerchen"; // Mindestens 8 Zeichen

WiFiServer server(80);

// --- Pin-Belegung CNC Shield V3 ---
const int STEP_A = 2;  const int DIR_A = 5;
const int STEP_B = 3;  const int DIR_B = 6;
const int STEP_C = 4;  const int DIR_C = 7;
const int STEP_D = 12; const int DIR_D = 13;
const int ENA_PIN = 8;

void setup() {
  Serial.begin(115200);

  pinMode(STEP_A, OUTPUT); pinMode(DIR_A, OUTPUT);
  pinMode(STEP_B, OUTPUT); pinMode(DIR_B, OUTPUT);
  pinMode(STEP_C, OUTPUT); pinMode(DIR_C, OUTPUT);
  pinMode(STEP_D, OUTPUT); pinMode(DIR_D, OUTPUT);
  pinMode(ENA_PIN, OUTPUT);
  digitalWrite(ENA_PIN, HIGH); // Stromlos starten

  // Access Point starten
  Serial.println("Starte WLAN Access Point 'Baeromat3000'...");
  WiFi.beginAP(ssid, password);

  delay(3000);
  server.begin();
  Serial.println("AP ist bereit!");
  Serial.print("IP-Adresse: ");
  Serial.println(WiFi.localIP()); // Standardmäßig: 192.168.4.1
}

void stepMotor(int stepPin, int dirPin, int steps) {
  digitalWrite(ENA_PIN, LOW); // Motoren aktivieren
  delay(50);
  digitalWrite(dirPin, LOW);

  for (int i = 0; i < steps; i++) {
    digitalWrite(stepPin, HIGH);
    delayMicroseconds(4000);
    digitalWrite(stepPin, LOW);
    delayMicroseconds(4000);
  }

  digitalWrite(ENA_PIN, HIGH); // Wieder stromlos schalten
}

void loop() {
  WiFiClient client = server.available();

  if (client) {
    String currentLine = "";
    String requestString = "";
    
    while (client.connected()) {
      if (client.available()) {
        char c = client.read();
        requestString += c;
        
        if (c == '\n') {
          if (currentLine.length() == 0) {
            
            // HTTP Header senden
            client.println("HTTP/1.1 200 OK");
            
            // Befehle auswerten
            if (requestString.indexOf("/dispense?motor=A") != -1) {
              client.println("Content-type:text/plain; charset=utf-8");
              client.println("Connection: close");
              client.println();
              stepMotor(STEP_A, DIR_A, 1800);
              client.print("OK_A");
            } 
            else if (requestString.indexOf("/dispense?motor=B") != -1) {
              client.println("Content-type:text/plain; charset=utf-8");
              client.println("Connection: close");
              client.println();
              stepMotor(STEP_B, DIR_B, 1800);
              client.print("OK_B");
            } 
            else if (requestString.indexOf("/dispense?motor=C") != -1) {
              client.println("Content-type:text/plain; charset=utf-8");
              client.println("Connection: close");
              client.println();
              stepMotor(STEP_C, DIR_C, 1800);
              client.print("OK_C");
            } 
            else if (requestString.indexOf("/dispense?motor=D") != -1) {
              client.println("Content-type:text/plain; charset=utf-8");
              client.println("Connection: close");
              client.println();
              stepMotor(STEP_D, DIR_D, 1800);
              client.print("OK_D");
            } 
            else if (requestString.indexOf("/stop") != -1) {
              client.println("Content-type:text/plain; charset=utf-8");
              client.println("Connection: close");
              client.println();
              digitalWrite(ENA_PIN, HIGH);
              client.print("OK_STOP");
            } 
            else {
              // Hauptseite aus der index.h ausliefern
              client.println("Content-type:text/html; charset=utf-8");
              client.println("Connection: close");
              client.println();
              client.print(HTML_CONTENT);
            }
            break;
          } else {
            currentLine = "";
          }
        } else if (c != '\r') {
          currentLine += c;
        }
      }
    }
    client.stop();
  }
}