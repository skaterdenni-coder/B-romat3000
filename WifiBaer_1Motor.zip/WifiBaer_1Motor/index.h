const char HTML_CONTENT[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bäromat3000 - Musik & Automat</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #1a1a24;
      color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
      box-sizing: border-box;
    }

    .card {
      background: #262738;
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.5);
      text-align: center;
      width: 360px;
    }

    .logo-img {
      width: 100%;
      max-width: 260px;
      height: auto;
      border-radius: 12px;
      margin-bottom: 15px;
      object-fit: contain;
    }

    h1 {
      margin: 0 0 10px 0;
      font-size: 24px;
      color: #ffcc00;
    }

    .status {
      margin: 15px 0;
      padding: 12px;
      border-radius: 10px;
      background: #1a1a24;
      font-size: 14px;
      color: #2ecc71;
      border: 1px solid #33344a;
      font-weight: bold;
    }

    .lyrics-box {
      background: #15151c;
      border-radius: 10px;
      padding: 12px;
      margin: 15px 0;
      min-height: 50px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-style: italic;
      color: #ffcc00;
      font-size: 15px;
      border: 1px dashed #444558;
    }

    .btn {
      width: 100%;
      padding: 14px;
      margin: 8px 0;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .btn:active {
      transform: scale(0.98);
    }

    .btn-dispense { 
      background: #ffcc00; 
      color: #1a1a24; 
      box-shadow: 0 4px 15px rgba(255, 204, 0, 0.2);
    }
    .btn-dispense:hover { background: #e6b800; }
    .btn-dispense:disabled { background: #444558; color: #777; cursor: not-allowed; box-shadow: none; }

    .btn-stop { background: #e74c3c; color: #fff; }
    .btn-stop:hover { background: #c0392b; }
  </style>
</head>
<body>

  <div class="card">
    <!-- Optional: Wenn du ein Logo hast, lege es im gleichen Ordner ab -->
    <!-- <img src="Logo.jpg" alt="Bäromat3000 Logo" class="logo-img"> -->
    
    <h1>Bäromat3000</h1>
    <div class="status">Status: <span id="statusText" style="color: #2ecc71;">Verbunden (WLAN)</span></div>

    <div class="lyrics-box" id="lyricsDisplay">Bereit für die Süßigkeiten-Hymne... 🎶</div>

    <button id="dispenseBtn" class="btn btn-dispense">Automat starten</button>
    <button id="stopBtn" class="btn btn-stop">⛔ Not-Aus / Stromlos</button>
  </div>

  <script>
    let audioCtx;

    const dispenseBtn = document.getElementById('dispenseBtn');
    const stopBtn = document.getElementById('stopBtn');
    const statusText = document.getElementById('statusText');
    const lyricsDisplay = document.getElementById('lyricsDisplay');

    // Melodie-Player (Web Audio API) & Songtext-Synchronisation + WLAN-Request
    async function playSongAndDispense() {
      if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }

      dispenseBtn.disabled = true;
      statusText.innerText = "Ausgabe & Song läuft...";
      statusText.style.color = "#ffcc00";

      // Signal per WLAN an den Arduino senden (Motor starten)
      try {
        await fetch('/dispense');
      } catch (err) {
        console.error("Netzwerkfehler:", err);
      }

      // Song-Daten: [Note (Hz), Dauer in ms, "Anzuzeigender Text"]
      const songNotes = [
        { freq: 261.63, duration: 250, text: "Der Bäromat dreht sich im Takt," },
        { freq: 329.63, duration: 250, text: "der Bäromat dreht sich im Takt!" },
        { freq: 392.00, duration: 250, text: "Goldbären fliegen durch die Nacht," },
        { freq: 523.25, duration: 500, text: "weil uns das glücklich macht!" },
        { freq: 440.00, duration: 250, text: "Schritt für Schritt," },
        { freq: 392.00, duration: 250, text: "jetzt naschen alle mit!" },
        { freq: 349.23, duration: 250, text: "Die Spirale rotiert," },
        { freq: 329.63, duration: 500, text: "bis die Portion einmarschiert!" },
        { freq: 293.66, duration: 250, text: "Zucker pur," },
        { freq: 261.63, duration: 750, text: "die süßeste Maschinen-Kultur!" }
      ];

      // Melodie sequenziell abspielen
      for (let note of songNotes) {
        lyricsDisplay.innerText = `"${note.text}"`;
        playTone(note.freq, note.duration);
        await sleep(note.duration + 50);
      }

      lyricsDisplay.innerText = "Genieß deine Gummibärchen!";
      
      setTimeout(() => {
        statusText.innerText = "Verbunden (WLAN)";
        statusText.style.color = "#2ecc71";
        dispenseBtn.disabled = false;
      }, 2000);
    }

    function playTone(freq, duration) {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'triangle'; // Weicher, spieluhr-artiger Klang
      osc.frequency.value = freq;

      gain.gain.setValueAtTime(0.6, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + (duration / 1000));

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + (duration / 1000));
    }

    function sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    dispenseBtn.addEventListener('click', playSongAndDispense);

    stopBtn.addEventListener('click', async () => {
      try {
        await fetch('/stop');
        statusText.innerText = "Motor Gestoppt / Stromlos";
        statusText.style.color = "#e74c3c";
        dispenseBtn.disabled = false;
        lyricsDisplay.innerText = "Gestoppt.";
      } catch (err) {
        console.error("Stop-Fehler:", err);
      }
    });
  </script>
</body>
</html>
)rawliteral";