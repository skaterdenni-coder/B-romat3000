const char HTML_CONTENT[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bäromat3000 - Multi-Fach Control</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #1a1a24;
      color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
      box-sizing: border-box;
    }

    .card {
      background: #262738;
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.5);
      text-align: center;
      width: 360px;
    }

    .logo-container {
      margin-bottom: 15px;
      display: flex;
      justify-content: center;
    }

    h1 {
      margin: 0 0 10px 0;
      font-size: 24px;
      color: #ffcc00;
    }

    .status {
      margin: 15px 0;
      padding: 12px;
      border-radius: 10px;
      background: #1a1a24;
      font-size: 14px;
      color: #2ecc71;
      border: 1px solid #33344a;
      font-weight: bold;
    }

    .grid-container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      margin: 15px 0;
    }

    .lyrics-box {
      background: #15151c;
      border-radius: 10px;
      padding: 12px;
      margin: 15px 0;
      min-height: 50px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-style: italic;
      color: #ffcc00;
      font-size: 15px;
      border: 1px dashed #444558;
    }

    .btn {
      width: 100%;
      padding: 14px;
      border: none;
      border-radius: 10px;
      font-size: 15px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .btn:active {
      transform: scale(0.98);
    }

    .btn-fach {
      background: #2e3044;
      color: #ffcc00;
      border: 1px solid #444558;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    }
    .btn-fach:hover { background: #3b3e56; border-color: #ffcc00; }
    .btn-fach:disabled { background: #444558; color: #777; cursor: not-allowed; border-color: #33344a; }

    .btn-stop { 
      background: #e74c3c; 
      color: #fff; 
      width: 100%;
      margin-top: 5px;
      padding: 14px;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
    }
    .btn-stop:hover { background: #c0392b; }
  </style>
</head>
<body>

  <div class="card">
    <!-- Integriertes Vektor-Logo (oder ersetze das <svg> durch dein <img> mit vollständigem Base64) -->
    <div class="logo-container">
      <svg width="110" height="110" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
        <rect x="10" y="10" width="100" height="100" rx="22" fill="#1a1a24" stroke="#ffcc00" stroke-width="4"/>
        <!-- Bären-Ohren -->
        <circle cx="42" cy="42" r="11" fill="#ffcc00"/>
        <circle cx="78" cy="42" r="11" fill="#ffcc00"/>
        <circle cx="42" cy="42" r="5" fill="#1a1a24"/>
        <circle cx="78" cy="42" r="5" fill="#1a1a24"/>
        <!-- Bären-Kopf -->
        <circle cx="60" cy="62" r="24" fill="#ffcc00"/>
        <!-- Augen & Schnauze -->
        <circle cx="52" cy="57" r="3" fill="#1a1a24"/>
        <circle cx="68" cy="57" r="3" fill="#1a1a24"/>
        <ellipse cx="60" cy="67" rx="7" ry="5" fill="#fff"/>
        <circle cx="60" cy="65" r="2.5" fill="#1a1a24"/>
        <!-- Zahnrad-Akzent -->
        <path d="M56 96 L64 96 L62 103 L58 103 Z" fill="#e74c3c"/>
      </svg>
    </div>
    
    <h1>Bäromat3000</h1>
    <div class="status">Status: <span id="statusText" style="color: #2ecc71;">Verbunden (WLAN)</span></div>

    <div class="lyrics-box" id="lyricsDisplay">Wähle ein Fach für die Ausgabe... 🎶</div>

    <div class="grid-container">
      <button class="btn btn-fach" onclick="triggerDispense('A')">🍬 Fach 1</button>
      <button class="btn btn-fach" onclick="triggerDispense('B')">🍬 Fach 2</button>
      <button class="btn btn-fach" onclick="triggerDispense('C')">🍬 Fach 3</button>
      <button class="btn btn-fach" onclick="triggerDispense('D')">🍬 Fach 4</button>
    </div>

    <button id="stopBtn" class="btn btn-stop" onclick="triggerStop()">⛔ Not-Aus / Stromlos</button>
  </div>

  <script>
    let audioCtx;
    const statusText = document.getElementById('statusText');
    const lyricsDisplay = document.getElementById('lyricsDisplay');
    const fachButtons = document.querySelectorAll('.btn-fach');

    async function triggerDispense(motor) {
      if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }

      fachButtons.forEach(btn => btn.disabled = true);
      statusText.innerText = `Fach ${motor} läuft...`;
      statusText.style.color = "#ffcc00";

      try {
        await fetch(`/dispense?motor=${motor}`);
      } catch (err) {
        console.error("Netzwerkfehler:", err);
      }

      const songNotes = [
        { freq: 261.63, duration: 250, text: "Der Bäromat dreht sich im Takt," },
        { freq: 329.63, duration: 250, text: "der Bäromat dreht sich im Takt!" },
        { freq: 392.00, duration: 250, text: "Goldbären fliegen durch die Nacht," },
        { freq: 523.25, duration: 500, text: "weil uns das glücklich macht!" },
        { freq: 440.00, duration: 250, text: "Schritt für Schritt," },
        { freq: 392.00, duration: 250, text: "jetzt naschen alle mit!" },
        { freq: 349.23, duration: 250, text: "Die Spirale rotiert," },
        { freq: 329.63, duration: 500, text: "bis die Portion einmarschiert!" },
        { freq: 293.66, duration: 250, text: "Zucker pur," },
        { freq: 261.63, duration: 750, text: "die süßeste Maschinen-Kultur!" }
      ];

      for (let note of songNotes) {
        lyricsDisplay.innerText = `"${note.text}"`;
        playTone(note.freq, note.duration);
        await sleep(note.duration + 50);
      }

      lyricsDisplay.innerText = "Genieß deine Gummibärchen! 🍬";
      
      setTimeout(() => {
        statusText.innerText = "Verbunden (WLAN)";
        statusText.style.color = "#2ecc71";
        fachButtons.forEach(btn => btn.disabled = false);
      }, 2000);
    }

    function playTone(freq, duration) {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'triangle';
      osc.frequency.value = freq;

      gain.gain.setValueAtTime(0.6, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + (duration / 1000));

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + (duration / 1000));
    }

    function sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function triggerStop() {
      try {
        await fetch('/stop');
        statusText.innerText = "Motor Gestoppt / Stromlos";
        statusText.style.color = "#e74c3c";
        fachButtons.forEach(btn => btn.disabled = false);
        lyricsDisplay.innerText = "Gestoppt.";
      } catch (err) {
        console.error("Stop-Fehler:", err);
      }
    }
  </script>
</body>
</html>
)rawliteral";